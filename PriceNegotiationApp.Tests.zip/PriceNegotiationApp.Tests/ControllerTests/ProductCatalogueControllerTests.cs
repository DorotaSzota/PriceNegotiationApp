﻿using PriceNegotiationApp.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FakeItEasy;
using Microsoft.AspNetCore.Mvc;
using PriceNegotiationApp.Controllers;

namespace PriceNegotiationApp.Tests.ControllerTests
{
    public class ProductCatalogueControllerTests
    {
        private readonly IProductCatalogueService _productCatalogueService;

        public ProductCatalogueControllerTests()
        {
            _productCatalogueService = A.Fake<IProductCatalogueService>();
        }

        [Fact]
        public async Task GetAllProducts_ReturnsOk()
        {
            //Arrange
            var controller = new ProductCatalogueController(_productCatalogueService);

            //Act
            var result = await controller.GetAll();

            //Assert
            Assert.IsType<OkObjectResult>(result.Result);
        }

    }
}

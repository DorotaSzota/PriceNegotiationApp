﻿using AutoMapper;
using FakeItEasy;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PriceNegotiationApp.Data;
using PriceNegotiationApp.Exceptions;
using PriceNegotiationApp.Models;
using PriceNegotiationApp.Services;

namespace PriceNegotiationApp.Tests.ProductCatalogueServiceTests;

public class ProductCatalogueServiceTests
{
    private readonly IMapper _mapper;
    private readonly PriceNegotiationDbContext _dbContext;
    private readonly ILogger<ProductCatalogueService> _logger;

    public ProductCatalogueServiceTests()
    {
        var options = new DbContextOptionsBuilder<PriceNegotiationDbContext>()
            .UseInMemoryDatabase(databaseName: "PriceNegotiationProxyDb")
            .Options;
        _mapper = A.Fake<IMapper>();
        _dbContext = new PriceNegotiationDbContext(options);
        _logger = A.Fake<ILogger<ProductCatalogueService>>();
    }

    [Fact]
    public async Task ProductCatalogueService_GetAllProducts_ReturnsAllProductsList()
    {
        // Arrange
        var service = new ProductCatalogueService(_mapper, _dbContext, _logger);
        _dbContext.Products.AddRange(new List<Product>()
        {
            new Product()
            {
                Id = 1,
                ProductName = "Omega Smartphone",
                ProductCategory = ProductCategory.Electronics,
                ProductDescription = "This is not even its final form.",
                ProductPrice = 999.99m,
                IsAvailable = true
            },
            new Product()
            {
                Id = 2,
                ProductName = "Shovel Ultra Pro 9000",
                ProductCategory = ProductCategory.Garden,
                ProductDescription = "Best suited for a shovel knight.",
                ProductPrice = 549.99m,
                IsAvailable = true
            }
        });

        // Act
        var result = await service.GetAllProducts();

        // Assert
        result.Should().NotBeNull().And.BeAssignableTo<List<GetProductDto>>();

    }

    [Fact]
    public async Task ProductCatalogueService_GetProductById_ProductNotFound()
    {
        // Arrange
        var service = new ProductCatalogueService(_mapper, _dbContext, _logger);

        // Act and Assert
        await Assert.ThrowsAsync<NotFoundException>(async () => await service.GetProductById(100));
    }

}